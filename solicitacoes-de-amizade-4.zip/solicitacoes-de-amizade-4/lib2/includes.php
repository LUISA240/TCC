<?php
	session_start();
	$_SESSION['userLogin'] = "thsales061";
	include_once("dbconnect.php");
	include_once("functions.php");
?>